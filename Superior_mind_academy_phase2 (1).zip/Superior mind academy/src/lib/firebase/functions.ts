"use client";

import { getFunctions, httpsCallable } from "firebase/functions";
import app from "./config";
import type { AccountStatus, CreateUserInput, UpdateUserInput, UserRole } from "@/types";

const functions = getFunctions(app);

export class ManageUserError extends Error {
  code: string;
  constructor(code: string, message: string) {
    super(message);
    this.code = code;
    this.name = "ManageUserError";
  }
}

/** Callable functions throw a FirebaseError with a `.code` like "functions/permission-denied". Turn it into a friendly, on-brand message. */
function toFriendlyMessage(code: string, fallback: string): string {
  switch (code) {
    case "functions/permission-denied":
      return "You don't have permission to do that.";
    case "functions/unauthenticated":
      return "Your session has expired. Please sign in again.";
    case "functions/invalid-argument":
      return fallback || "Some of the details provided weren't valid.";
    case "functions/not-found":
      return "That account no longer exists.";
    case "functions/failed-precondition":
      return fallback || "That action isn't allowed right now.";
    case "functions/already-exists":
      return "An account with that email already exists.";
    default:
      return fallback || "Something went wrong. Please try again.";
  }
}

async function callFunction<TInput extends object, TOutput>(
  name: string,
  data: TInput
): Promise<TOutput> {
  try {
    const callable = httpsCallable<TInput, TOutput>(functions, name);
    const result = await callable(data);
    return result.data;
  } catch (err) {
    const code = (err as { code?: string })?.code ?? "functions/unknown";
    const message = (err as { message?: string })?.message ?? "";
    throw new ManageUserError(code, toFriendlyMessage(code, message));
  }
}

export function createStaffAccount(
  input: CreateUserInput
): Promise<{ uid: string }> {
  return callFunction("createStaffAccount", input);
}

export function updateStaffAccount(
  input: UpdateUserInput
): Promise<{ ok: true }> {
  return callFunction("updateStaffAccount", input);
}

export function setUserRole(uid: string, role: UserRole): Promise<{ ok: true }> {
  return callFunction("setUserRole", { uid, role });
}

export function resetStaffPassword(uid: string): Promise<{ temporaryPassword: string }> {
  return callFunction("resetStaffPassword", { uid });
}

export function deleteStaffAccount(uid: string): Promise<{ ok: true }> {
  return callFunction("deleteStaffAccount", { uid });
}

/** Convenience wrapper for the common "suspend" / "reactivate" toggle, built on updateStaffAccount. */
export function setUserStatus(uid: string, status: AccountStatus): Promise<{ ok: true }> {
  return updateStaffAccount({ uid, status });
}
