export * from "./user";

export interface NavItem {
  label: string;
  href: string;
  icon?: string;
}

export interface ApiError {
  code: string;
  message: string;
}
